$(document).ready(function () {
    $('ul.tabs').tabs({
        swipeable: true,
        responsiveThreshold: 1920
    });
});

$.getJSON("https://jsonplaceholder.typicode.com/posts", function (data) {
    var items = [];
    console.log();
    $.each(data, function (key, val) {
        console.log("test", val);
        items.push("<div class='content'><div id='" + key + "' class='title'>" + val.title + "</div><div id='" + key + "'  class='subtxt'>" + val.body + "</div></div>");
    });

    $("<div/>", {
        html: items.join("")
    }).appendTo(".contentwrapper");
});