Setup Project:

> npm i
> grunt

After start server it eill goes to http://localhost:3000
you can check this app in your mobile using your machine IP
e.g 192.168.1.101:3000

Or 

Simply you can open index.html directly
